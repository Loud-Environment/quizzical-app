import React from "react";
import { IoIosArrowDown, IoIosArrowUp } from "react-icons/io";

export default function QuizOptions({ handleSubmit }) {
  const [optionsShown, setOptionsShown] = React.useState(false);

  return (
    <form className="form-api" onSubmit={handleSubmit}>
      <button
        onClick={() => {
          setOptionsShown((prev) => !prev);
        }}
        className="options-header"
        type="button"
        aria-expanded={optionsShown}
      >
        {!optionsShown ? "Show quiz options" : "Hide quiz options"}
        {!optionsShown ? <IoIosArrowDown /> : <IoIosArrowUp />}
      </button>
      {optionsShown ? (
        <>
          <label className="trivia_amount_class" htmlFor="trivia_amount">
            Number of Questions (1-10)
          </label>
          <input
            type="number"
            id="trivia_amount"
            name="trivia_amount"
            placeholder="5"
            min="1"
            max="10"
            defaultValue="5"
            className="form-control"
          />
          <label htmlFor="trivia_category">Select Category: </label>
          <select name="trivia_category" className="form-control">
            <option value="any">Any Category</option>
            <option value="9">General Knowledge</option>
            <option value="10">Entertainment: Books</option>
            <option value="11">Entertainment: Film</option>
            <option value="12">Entertainment: Music</option>
            <option value="13">Entertainment: Musicals &amp; Theatres</option>
            <option value="14">Entertainment: Television</option>
            <option value="15">Entertainment: Video Games</option>
            <option value="16">Entertainment: Board Games</option>
            <option value="17">Science &amp; Nature</option>
            <option value="18">Science: Computers</option>
            <option value="19">Science: Mathematics</option>
            <option value="20">Mythology</option>
            <option value="21">Sports</option>
            <option value="22">Geography</option>
            <option value="23">History</option>
            <option value="24">Politics</option>
            <option value="25">Art</option>
            <option value="26">Celebrities</option>
            <option value="27">Animals</option>
            <option value="28">Vehicles</option>
            <option value="29">Entertainment: Comics</option>
            <option value="30">Science: Gadgets</option>
            <option value="31">
              Entertainment: Japanese Anime &amp; Manga
            </option>
            <option value="32">
              Entertainment: Cartoon &amp; Animations
            </option>{" "}
          </select>
          <label htmlFor="trivia_difficulty">Select Difficulty: </label>
          <select name="trivia_difficulty" className="form-control">
            <option value="any">Any Difficulty</option>
            <option value="easy">Easy</option>
            <option value="medium">Medium</option>
            <option value="hard">Hard</option>
          </select>
          <label htmlFor="trivia_type">Select Type: </label>
          <select name="trivia_type" className="form-control">
            &gt;
            <option value="any">Any Type</option>
            <option value="multiple">Multiple Choice</option>
            <option value="boolean">True / False</option>
          </select>
        </>
      ) : null}
      <button type="submit" className="options-submit">
        Start quiz
      </button>
    </form>
  );
}
